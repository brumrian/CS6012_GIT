package assignment02;
//Rian Brumfield

import java.util.GregorianCalendar;

public class LibraryBook extends Book{

    private String holder;
    private GregorianCalendar dueDate;


    public LibraryBook(long isbn, String author, String title) {
        super(isbn, author, title);
    }

    public String getHolder() {
        return holder;
    }

    public GregorianCalendar getDueDate() {
        return dueDate;
    }

    public void setHolder(String holder) {
        this.holder = holder;
    }

    public void setDueDate(GregorianCalendar dueDate) {
        this.dueDate = dueDate;
    }
}
